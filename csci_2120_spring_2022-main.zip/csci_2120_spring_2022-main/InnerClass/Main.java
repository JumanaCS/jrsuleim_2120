public class Main {

    public static void main(String[] args) {

    // if Inner is a member class, then I first need an instance of type Outer around

    Outer outerThing = new Outer();

    Outer.Inner innerThing = outerThing.new Inner();

    Outer.Inner anotherInnerThing = outerThing.new Inner();

    innerThing.doSomething(anotherInnerThing);

    }

} // end class Main
