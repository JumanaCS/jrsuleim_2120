public class Outer {

    private int foo;  // this thing is not static, so it's a property of an object
    private static int bar; // this thing IS labeled static, so it's a property of the class Outer

    public void doSometingInOuter() {

        this.foo = 10;
        // the keyword "this" is a reference to the current object - like "me" or "my"

    }


    public class Inner {
        private double fubar;

        public void doSomething(Inner blah) {

            this.fubar = 20.5; // "this" is referring to the current Inner

            Outer.this.foo = 7; // "Outer.this" is referring to the current Outer of which I am a member - like saying "My Outher Object's foo instance variable"
            
        }

    } // end classs Inner



} // end class Outer
