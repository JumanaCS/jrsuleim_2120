import java.util.List;
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {

		Dog d1 = new Dog("Spike", 10.0, 10.0);
		Dog d2 = new Dog("Rover", 10.0, 10.0);
		Dog d3=  new Dog("Sparky", 10.0, 10.0);
		Dog d4 = new Dog("Clifford", 10.0, 10.0);
		Dog d5 = new Dog("Furry", 10.0, 10.0);
		Dog d6 = new Dog("Mia", 10.0, 10.0);
		Dog d7 = new Dog("Vinny", 10.0, 10.0);
		Dog d8 = new Dog("Andy", 10.0, 10.0);

		List<Dog> list = new ArrayList<Dog>();

		list.add(d1);
		list.add(d2);
		list.add(d3);
		list.add(d4);
		list.add(d5);
		list.add(d6);
		list.add(d7);
		list.add(d8);

		Sorters.bubbleSort(list);

		System.out.println("Printing sorted list:");
		for (int i=0; i<list.size(); i++) {
			System.out.println(list.get(i));
		}
	}

} // end class
