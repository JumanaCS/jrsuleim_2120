import java.util.List;

public class Sorters {

	public static <T extends Comparable<T>> void selectionSort(List<T> list) {
		// find the smallest
		// swap it with "first position"
		// move "first position" forward by one and find smallest again

		for (int firstPosition = 0; firstPosition < list.size() -1 ; firstPosition++) {
			int indexOfSmallest = findSmallest(firstPosition,list);
			swap(list,firstPosition,indexOfSmallest);
		}
	} // end selectionSort

	public static <T extends Comparable<T>> void bubbleSort(List<T> list) {


	    for (int last = list.size() -1; last >0; last --) {

		boolean swapHappened = false;

		for (int i = 0; i < last; i++) {
			if ( list.get(i).compareTo(list.get(i+1)) > 0 ) {
				swap(list,i,i+1);
				swapHappened = true;
	                }
		}
		if (!swapHappened)
			return;
	    }


	} // end bubble sort

	public static <T extends Comparable<T>> int findSmallest(int first, List<T> list) {
		int indexOfSmallest = first;
		for (int i = first+1; i < list.size(); i++) {
			if ( list.get(i).compareTo(list.get(indexOfSmallest)) < 0 )
				indexOfSmallest = i;
		}
		return indexOfSmallest;

	} // end findSmallest

	public static <T> void swap(List<T> list, int first, int second) {
		T temp = list.get(first);
		list.set(first, list.get(second));
		list.set(second, temp);
	}

} // end class Sorters
