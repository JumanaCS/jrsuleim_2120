public class Main {

    public static void main(String[] args) {

        final Dog fifi = new Dog("fifi", 10.5, 11.6);

        // final above prevents me from doing this
        fifi = new Dog("george",30.6, 12,8);

        // it does NOT prevent this:

        fifi.setName("Lil Weezy");

    }

}
