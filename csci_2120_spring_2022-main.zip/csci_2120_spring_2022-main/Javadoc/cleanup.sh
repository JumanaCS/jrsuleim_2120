#!/bin/sh

rm -f *.html
rm -f *.css
rm -f *.js
rm -f package-list
rm -fr jquery resources/
rm -fr legal
rm -fr script-dir
rm -f package-search-index.zip type-search-index.zip 
rm -r element-list 
