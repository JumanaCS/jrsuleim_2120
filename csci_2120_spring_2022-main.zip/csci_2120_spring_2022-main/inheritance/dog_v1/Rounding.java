public class Rounding {

	public static void main(String[] args) {

		double sum = 1.0/6.0 +  1.0/6.0 +  1.0/6.0 +  1.0/6.0 +  1.0/6.0 +  1.0/6.0;
		System.out.println("sum is " + sum);

	}


}
