public class Kennel {

	// without Dog supertype
	private Poodle[] allThePoodles;
	private Rottweiler[] allTheRotties;
	private Chihuahua[] allTheChihuahuas;

	// with Dog supertype
	private Dog[] allTheDogs;

} // end class Kennel
