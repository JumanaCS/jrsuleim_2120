public class Snake implements Animal{

	public void move() {
		System.out.println("I'm slithering");
	}
}
