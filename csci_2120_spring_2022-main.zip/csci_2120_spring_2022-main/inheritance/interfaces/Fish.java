public class Fish implements Animal{

	public void move() {
		System.out.println("I'm swimming");
	}
}
