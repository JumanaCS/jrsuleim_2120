public class Bird implements Animal {

	public void move() {
		System.out.println("I'm flying");
	}
}
