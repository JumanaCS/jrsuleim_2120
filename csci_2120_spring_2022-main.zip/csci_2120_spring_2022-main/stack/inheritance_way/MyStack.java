import java.util.ArrayList;

public class MyStack<T> extends ArrayList<T> {

	public MyStack() {

	}

	public void push(T element) {
		add(0,element); // poor choice O(N)
	}

	public T pop() {
		return remove(0); // poor choice O(N)
	}

} // end class MyStack
