import java.util.ArrayList;

public class MyStack<T> {

	private ArrayList<T> data;

	public MyStack() {

		data = new ArrayList<T>();
	}

	public size() {
		return data.size();
	}

	public void push(T element) {
		data.add(0,element); // poor choice O(N)
	}

	public T pop() {
		return data.remove(0); // poor choice O(N)
	}

} // end class MyStack
